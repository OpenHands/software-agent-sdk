"""Disposable live-evidence bundle; identical in local and Docker workspaces."""
from contextlib import closing
import json
import importlib.util
import hashlib
import inspect
import os
from pathlib import Path
import time
from uuid import UUID

from openhands.sdk import RemoteConversation, RemoteWorkspace
from openhands.sdk.conversation.response_utils import get_agent_final_response
from openhands.tools import register_default_tools

register_default_tools()
assert importlib.util.find_spec('openhands.sdk.client') is None, 'Stale removed SDK client module remains installed'
conversation_id = UUID(os.environ['AUTOMATION_CONVERSATION_ID'])
source = Path(inspect.getfile(RemoteConversation))
print('SDK_SOURCE: ' + json.dumps({'remote_conversation_file': str(source), 'remote_conversation_sha256': hashlib.sha256(source.read_bytes()).hexdigest()}), flush=True)
workspace_path = Path(os.environ['WORKSPACE_BASE'])
workspace_path.mkdir(parents=True, exist_ok=True)
with RemoteWorkspace(
    host=os.environ['AGENT_SERVER_URL'],
    api_key=os.environ['SESSION_API_KEY'],
    working_dir=str(workspace_path),
) as workspace, closing(RemoteConversation(agent=None, workspace=workspace, conversation_id=conversation_id)) as conversation:
    uploaded = workspace.file_upload(b'{"fixture":"canonical-workspace-api"}\n', workspace_path / 'sdk-input.json')
    assert uploaded.success, uploaded.error
    command_id = workspace.start_command('cat sdk-input.json', cwd=workspace_path)
    output = None
    deadline = time.monotonic() + 30
    while time.monotonic() < deadline:
        output = workspace.get_command_output(command_id)
        if output is not None and output.get('exit_code') is not None:
            break
        time.sleep(0.25)
    assert output is not None and output.get('exit_code') == 0, 'SDK fixture command did not complete'
    assert 'canonical-workspace-api' in output.get('stdout', ''), 'SDK uploaded bytes were not returned'
    print('SDK_WORKSPACE_API: byte upload and background command output verified', flush=True)
    conversation.send_message(
        'This is a disposable infrastructure validation workspace. Use the terminal tool '
        'to read sdk-input.json and confirm its fixture string is canonical-workspace-api. '
        'Write fixture.json containing {"fixture":"canonical-workspace-api","verified":true}, '
        'read the file back, and finish with a short sentence confirming the result. '
        'Do not access the network or any repository.'
    )
    conversation.run(timeout=180)
    print('AGENT_FINISHED: ' + get_agent_final_response(conversation.state.events), flush=True)
print('EVIDENCE_INSPECT: 60 seconds for the real Canvas file and workspace checks', flush=True)
time.sleep(60)
print('EVIDENCE_BUNDLE_COMPLETED', flush=True)
